#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"

static void add_employee(MYSQL *conn)
{
    MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[9]; 

    // Input for the registration routine
    char fiscal_code[16];
	char name[20];
	char surname[20];
    MYSQL_TIME born;
    char location_born[45];
    char location_actual[60];
    char email[60];
    char task[45];
	char username[45];
    char app[5];

    bool ID;
	
    // Get the required information
	printf("\nEmployee fiscal code: ");
	getInput(16, fiscal_code, false);
	printf("Employee name: ");
	getInput(20,name, false);
	printf("Employee surname: ");
	getInput(20, surname, false);
    

    printf("Employee year of birth: ");
	getInput(4,app, false);
    born->year = atoi(app);
    printf("Employee month of birth: ");
	getInput(2,app, false);
    born->month = atoi(app);
    printf("Employee day of birth: ");
	getInput(2,app, false);
    born->day = atoi(app);
    
    printf("Employee city of birth: ");
	getInput(45, location_born, false);
    printf("Employee residency: ");
	getInput(60, location_actual, false);
    printf("Employee email: ");
	getInput(60, email, false);
    printf("Employee task: ");
	getInput(45, task, false);
    printf("Employee username: ");
	getInput(45, username, false);

    // Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call aggiungi_dipendente(?, ?, ?, ?,?, ?, ?, ?,?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize employee insertion statement\n", false);
	}
    // Prepare parameters
	memset(param, 0, sizeof(param));

    param[0].buffer_type = MYSQL_TYPE_STRING;
	param[0].buffer = fiscal_code;
	param[0].buffer_length = strlen(name);

    param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = name;
	param[1].buffer_length = strlen(name);

    param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = surname;
	param[2].buffer_length = strlen(surname);

    param[3].buffer_type = MYSQL_TYPE_TIME;
	param[3].buffer = born;
	param[3].buffer_length = strlen(born);

    param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer = location_born;
	param[4].buffer_length = strlen(location_born);

    param[5].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[5].buffer = location_actual;
	param[5].buffer_length = strlen(location_actual);

    param[6].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[6].buffer = email;
	param[6].buffer_length = strlen(email);

    param[7].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[7].buffer = task;
	param[7].buffer_length = strlen(task);

    param[8].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[8].buffer = username;
	param[8].buffer_length = strlen(username);

    if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for student insertion\n", true);
	}

    // Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while adding the student.");
		goto out;
	}

    // Get back the ID of the newly-added employee
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_TINY; // OUT
	param[0].buffer = &ID;
	param[0].buffer_length = sizeof(ID);
	
	if(mysql_stmt_bind_result(prepared_stmt, param)) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve output parameter", true);
	}
	
	// Retrieve output parameter
	if(mysql_stmt_fetch(prepared_stmt)) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not buffer results", true);
	}
    if(ID = 1){
        printf("Employee correctly added...\n");
    }
	

    out:
	mysql_stmt_close(prepared_stmt);


}

static void create_user(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[3];
	char options[4] = {'1','2', '3','4'};
	char r;

	// Input for the registration routine
	char username[45];
	char password[45];
	char ruolo[46];

	// Get the required information
	printf("\nUsername: ");
	getInput(46, username, false);
	printf("password: ");
	getInput(46, password, true);
	printf("Assign a possible role:\n");
	printf("\t1) Dipendente\n");
	printf("\t2) Dipendente Spazi\n");
	printf("\t3) Dipendente Amministrazione\n");
    printf("\t4) Sistemista\n");
	r = multiChoice("Select role", options, 4);

	// Convert role into enum value
	switch(r) {
		case '1':
			strcpy(ruolo, "dipendente");
			break;
		case '2':
			strcpy(ruolo, "dipSpazi");
			break;
		case '3':
			strcpy(ruolo, "dipAmministrazione");
			break;
        case '4':
            strcpy(ruolo, "sistemista");
			break;
		default:
			fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
			abort();
	}

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call crea_utente(?, ?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize user insertion statement\n", false);
	}

	// Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = password;
	param[1].buffer_length = strlen(password);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = ruolo;
	param[2].buffer_length = strlen(ruolo);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for user insertion\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding the user.");
	} else {
		printf("User correctly added...\n");
	}

	mysql_stmt_close(prepared_stmt);
}

void run_as_administrator(MYSQL *conn){
    //menu options
    char options[5] = {'1','2', '3', '4', '5'};
    char op;

    printf("\033[2J\033[H");
    printf("Switching to administrative role...\n");
    
    //change login user to administrator user
    if(!parse_config("users/amministratore.json", &conf)) {
		fprintf(stderr, "Unable to load administrator configuration\n");
		exit(EXIT_FAILURE);
	}

    if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}
    while(true){
        //show menu
 
        printf("*** What should I do for you? ***\n\n");
        printf("1) Create new user\n");
        printf("2) Add new employee\n");
        printf("-------Research operations-------\n");
		printf("3) Find an employee\n");
		printf("4) Find a number\n");
        printf("5) Quit\n\n");


        op = multiChoice("Select an option", options, 5);

        switch (op)
        {
        case '1':
            create_user(conn);
            break;
        case '2':
            add_employee(conn);
            break;
        case '3':
            find_employee(conn);
            break;
        case '4':
            find_number(conn);
            break;
        case '5':
            return;
        
        default:
            fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
			abort();
        }
        printf("\n\nPLEASE INSERT ENTER TO CONTINUE\n");
        getchar();
    }
}
