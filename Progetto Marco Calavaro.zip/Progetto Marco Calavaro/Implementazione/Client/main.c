//conte_cvma main
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql.h>

#include "defines.h"


typedef enum {
	EMPLOYEE = 1,
	EMPLOYEE_SPAZI,
	EMPLOYEE_ADMI,
	ADMINISTRATOR,
	FAILED_LOGIN
} role_t;

struct configuration conf;

static MYSQL *conn;

static role_t attempt_login(MYSQL *conn, char *username, char *password) {
	MYSQL_STMT *login_procedure;
	
	MYSQL_BIND param[3]; // Used both for input and output
	int role = 0;

	if(!setup_prepared_stmt(&login_procedure, "call login(?, ?, ?)", conn)) {
		print_stmt_error(login_procedure, "Unable to initialize login statement\n");
		goto err2;
	}

	//Initialize parameters
	memset(param, 0, sizeof(param));


	param[0].buffer_type = MYSQL_TYPE_VAR_STRING; // IN
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING; // IN
	param[1].buffer = password;
	param[1].buffer_length = strlen(password);

	param[2].buffer_type = MYSQL_TYPE_LONG; // OUT
	param[2].buffer = &role;
	param[2].buffer_length = sizeof(role);

	if (mysql_stmt_bind_param(login_procedure, param) != 0) { // Note _param
		print_stmt_error(login_procedure, "Could not bind parameters for login");
		goto err;
	}
	//No error execute procedure
	if (mysql_stmt_execute(login_procedure) != 0) {
		print_stmt_error(login_procedure, "Could not execute login procedure");
		goto err;
	}
	/*
		No error prepare output
		using same MYSQL_BIND struct
	*/
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_LONG; // OUT
	param[0].buffer = &role;
	param[0].buffer_length = sizeof(role);

	if(mysql_stmt_bind_result(login_procedure, param)) {
		print_stmt_error(login_procedure, "Could not retrieve output parameter");
		goto err;
	}
	//No error fetch output parameter
	if(mysql_stmt_fetch(login_procedure)) {
		print_stmt_error(login_procedure, "Could not buffer results");
		goto err;
	}
	//No error close procedure
	mysql_stmt_close(login_procedure);
	return role;

	err:
	//Error in procedure
	mysql_stmt_close(login_procedure);
    err2:
	//Error in initialize procedure
	return FAILED_LOGIN;
}

int main(void){
	role_t role;
	if(!parse_config("users/login.json", &conf)) {
		fprintf(stderr, "Unable to load login configuration\n");
		exit(EXIT_FAILURE);
	}
	
	conn = mysql_init (NULL);
	if (conn == NULL) {
		fprintf (stderr, "mysql_init() failed\n");
		exit(EXIT_FAILURE);
	}
	
	fprintf (stderr, "host: %s\n",conf.host);
	fprintf (stderr, "db_username: %s\n",conf.db_username);
	fprintf (stderr, "db_password: %s\n",conf.db_password);
	fprintf (stderr, "database: %s\n",conf.database);
	fprintf (stderr, "port: %d\n",conf.port);

	if (mysql_real_connect(conn, conf.host, conf.db_username, conf.db_password, conf.database, conf.port, NULL, CLIENT_MULTI_STATEMENTS | CLIENT_MULTI_RESULTS) == NULL) {
		fprintf (stderr, "mysql_real_connect() failed: %s\n",mysql_error(conn));
		mysql_close (conn);
		exit(EXIT_FAILURE);
	}
	
	printf("Username: ");
	getInput(USER_SIZE, conf.username, false);
	printf("Password: ");
	getInput(USER_SIZE, conf.password, true);

	role = attempt_login(conn, conf.username, conf.password);
	fprintf(stderr,"role : %d\n",role);
	switch(role){

		case EMPLOYEE:
			//run employee client 
			run_as_employee(conn);
			break;
			
		case EMPLOYEE_SPAZI:
			//run employee_spazi client
			run_as_employee_spazi(conn);
			break;
			
		case EMPLOYEE_ADMI:
			//run employee_administration client
			run_as_employee_admi(conn);
			break;

		case ADMINISTRATOR:
			//run administrator client
			run_as_administrator(conn);
			break;

		case FAILED_LOGIN:
			fprintf(stderr, "Invalid credentials\n");
			exit(EXIT_FAILURE);
			break;

		default:
			fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
			abort();
	}
	printf("Bye!\n");

	mysql_close (conn);
	return 0;
}
