#include <stdio.h>
#include <stdlib.h>

#include "defines.h"


void run_as_employee(MYSQL *conn){
    char options[3] = {'1','2', '3'};
    char op;

    printf("Switching to Employee role...\n");

    //change login user to Sector Spazi user
    if(!parse_config("users/dipendente.json", &conf)) {
		fprintf(stderr, "Unable to load Sector Spazi configuration\n");
		exit(EXIT_FAILURE);
	}

    if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed:%s\n",mysql_error(conn));
		exit(EXIT_FAILURE);
	}

    while (true)
    {

       //show menu
        printf("\033[2J\033[H");
        printf("\n*** What should I do for you? ***\n\n");
        printf("1) Find an employee\n");
		printf("2) Find a number\n");
        printf("3) Quit\n\n");

        op = multiChoice("Select an option", options, 3);

        switch (op)
       {
        case '1':
            find_employee(conn);
            break;
        case '2':
            find_number(conn);
            break;
        case '3':
            return;
        default:
            fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
		    abort();
       }
       printf("\n\nPLEASE INSERT ENTER TO CONTINUE\n");
       getchar();
    }
}