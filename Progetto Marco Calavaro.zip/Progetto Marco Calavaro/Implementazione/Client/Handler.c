
#include <stdio.h>

void handler_ret(){
    printf("\n\nReceive a SIGINT\n");
    return;
}


