#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defines.h"


extern void find_employee(MYSQL *conn){
    char options[4] = {'1','2', '3','4'};
    char op;
    char Nome[20];
    char Cognome[20];
    bool is_nome_null = 0;
    bool is_cognome_null = 0;
    MYSQL_STMT *prepared_stmt;
    MYSQL_BIND param[2];
    //int status;
    char header[512];

    printf("\033[2J\033[H");
    printf("***FIND AN EMPLOYEE (1)***\n");
    printf("1) By name\n");
    printf("2) By surname\n");
    printf("3) By name, surname\n");
    printf("4) Back\n\n");

    op = multiChoice("Select an option", options, 4);
    printf("\033[2J\033[H");
    printf("***FIND AN EMPLOYEE (%s)***\n",&op);
    printf("A LOT OF INFORMATION VIEW FULL SCREEN\n");
    switch (op)
    {
        case '1':
            printf("Please enter the employee's name: ");
            getInput(20, Nome, false);
            //sprintf(Cognome,"NULL");
            //Cognome = NULL;
            is_cognome_null = 1;
            sprintf(header, "\nEmployees for name: %s",Nome);
            break;
        case '2':
            printf("Please enter the employee's surname: ");
            getInput(20, Cognome, false);
            //sprintf(Nome,"NULL");
            //Nome = NULL;
            is_nome_null = 1;
            sprintf(header, "\nEmployees for surname: %s",Cognome);
            break;

        case '3':
            printf("Please enter the employee's name: ");
            getInput(20, Nome, false);
            printf("Please enter the employee's surname: ");
            getInput(20, Cognome, false);
            sprintf(header, "\nEmployees for name, surname: %s, %s",Nome,Cognome);
            break;

        case '4':
            return;
    
        default:
            fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
            abort();
    }

    // Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call cerca_dipendente(?,?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize Info statement\n", false);
	}

    // Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = Nome;
	param[0].buffer_length = strlen(Nome);
    param[0].is_null =(char *) &is_nome_null;
    

    param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = Cognome;
	param[1].buffer_length = strlen(Cognome);
    param[1].is_null = (char *)&is_cognome_null;

    if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for offices info\n", true);
	}

    if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while retrieving the offices info.");
        
	}

    /*
    status = mysql_stmt_next_result(prepared_stmt);

    if (status > 0)
		finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);

    */
    //dump result
	dump_result_set(conn, prepared_stmt, header);
    mysql_stmt_close(prepared_stmt);
}


extern void find_number(MYSQL *conn){
    char options[3] = {'1','2','3'};
    char op;
    char Number[20];
    char header[512];
    bool int_number;
    MYSQL_STMT *prepared_stmt;
    MYSQL_BIND param[2];

    printf("\033[2J\033[H");
    printf("***FIND A NUMBER (1)***\n");
    printf("1) Internal nuber\n");
    printf("2) External number\n");
    printf("3) Back\n\n");

    op = multiChoice("Select an option", options, 3);

    switch (op){
        
        case '1':
            printf("Rules for internal number:\n9*-Building code-Floor number-Office number-Seat number\n\n[Building code: AA=001, BB=002, CC=003]\n(example: 9*-001-1-1-1 For building AA, floor 1, office 1, seat 1)\n");
            printf("\nPlease enter the number to be searched\n[ATTENTION use * and - according the rules]: ");
            getInput(20, Number, false);
            sprintf(header, "\nNumber info for: %s",Number);
            int_number = true;

            break;

        case '2':
            printf("Rules for external number:\n011-333-Building code-Floor number-Office number-Seat number\n\n[Building code: AA=001, BB=002, CC=003]\n(example: 011-333-001-1-1-1 For building AA, floor 1, office 1, seat 1)\n");
            printf("\nPlease enter the number to be searched\n[ATTENTION use - according the rules]: ");
            getInput(20, Number, false);
            sprintf(header, "\nNumber info for: %s",Number);
            int_number = false;

            break;

        case '3':
            return;

        default:
            fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
            abort();
    }
    // Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call cerca_telefono(?,?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize Info statement\n", false);
	}

    // Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = Number;
	param[0].buffer_length = strlen(Number);
    

    param[1].buffer_type = MYSQL_TYPE_TINY;
	param[1].buffer = &int_number;
	param[1].buffer_length = sizeof(bool);

    if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for offices info\n", true);
	}

    if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while retrieving the offices info.");
        
	}
    dump_result_set(conn, prepared_stmt, header);
    mysql_stmt_close(prepared_stmt);
}
