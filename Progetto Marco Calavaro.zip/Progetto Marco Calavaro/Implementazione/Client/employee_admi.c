#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

#include "defines.h"

struct sigaction act;
sigset_t set;


struct employee_info {
    char Nome[20];
    char Cognome[20];
    int Numero;
    int Piano;
    char Edificio[2];
};

static size_t parse_employee_info(MYSQL *conn, MYSQL_STMT *stmt, struct employee_info **ret){
    //function for multi employee info
    int status;
	size_t row = 0;
    MYSQL_BIND param[5];
    char Nome[20];
    char Cognome[20];
    int Numero = 0;
    int Piano = 0;
    char Edificio[2];

    if (mysql_stmt_store_result(stmt)) {
		fprintf(stderr, " mysql_stmt_execute(), 1 failed\n");
		fprintf(stderr, " %s\n", mysql_stmt_error(stmt));
		exit(0);
	}

    *ret = malloc(mysql_stmt_num_rows(stmt) * sizeof(struct employee_info));
    memset(param, 0, sizeof(param));

    param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = Nome;
	param[0].buffer_length = 20;

    param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = Cognome;
	param[1].buffer_length = 20;

    param[2].buffer_type =MYSQL_TYPE_LONG;
	param[2].buffer = &Numero;
	param[2].buffer_length = sizeof(int);

    param[3].buffer_type = MYSQL_TYPE_LONG;
	param[3].buffer = &Piano;
	param[3].buffer_length = sizeof(int);

    param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer = Edificio;
	param[4].buffer_length = 2;

    if(mysql_stmt_bind_result(stmt, param)) {
		finish_with_stmt_error(conn, stmt, "Unable to bind column parameters\n", true);
	}

    while (true) {
		status = mysql_stmt_fetch(stmt);

		if (status == 1 || status == MYSQL_NO_DATA)
			break;

		strcpy((*ret)[row].Nome, Nome);
        strcpy((*ret)[row].Cognome, Cognome);
        ret[row]->Numero = Numero;
        ret[row]->Piano = Piano;
        strcpy((*ret)[row].Edificio, Edificio);
		row++;
	}
				
	return row;

}

static void office_report(MYSQL *conn){
    
    MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[1];
    char username[USER_SIZE];
    int status;
    bool first = true;
    char header[512];
    


    struct employee_info *info;


    //show menu for help
    printf("\033[2J\033[H");
    printf("***OFFICE REPORT (1)***\n");

    if (yesOrNo("You want to find an employee first?",'y','n',false,true))
    {
        find_employee(conn);
        printf("\n\nPLEASE INSERT ENTER TO CONTINUE\n");
        getchar();
    }

    //start real function 
    printf("\033[2J\033[H");
    printf("***OFFICE REPORT (2)***\n");   
    printf("Please enter the employee's username: ");
    getInput(USER_SIZE, username, false);
    

    // Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call report_uffici_dipendente(?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize office report statement\n", false);
	}

    // Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for offices report\n", true);
	}
    // Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while retrieving the offices report.");
		goto out;
	}

    do
    {
        if(conn->server_status & SERVER_PS_OUT_PARAMS) {
			goto next;
		}

		if(first) {
			parse_employee_info(conn,prepared_stmt,&info);
            printf("\nEmployee: %s %s \n \tis currently in the office: %s-%d-%d\n",info[0].Nome, info[0].Cognome,info[0].Edificio,info[0].Piano,info[0].Numero);
			first = false;
            
		}
        else {
			sprintf(header, "\nPast offices info for employee: %s %s ", info[0].Nome, info[0].Cognome);
			dump_result_set(conn, prepared_stmt, header);
		}

		// more results? -1 = no, >0 = error, 0 = yes (keep looking)
	    next:
		status = mysql_stmt_next_result(prepared_stmt);
		if (status > 0)
			finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);

    } while (status == 0);
    
    out:
	mysql_stmt_close(prepared_stmt);


}

static void change_employee_task(MYSQL *conn){
    
    MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[3];
    char username[USER_SIZE];
    char task[TASK_SIZE];
    bool success = false;

  

    //show menu for help
    printf("\033[2J\033[H");
    printf("***CHANGE TASK (1)***\n");
    
    if (yesOrNo("You want to find an employee first?",'y','n',false,true))
    {
        find_employee(conn);
    }

    //real function
    printf("\033[2J\033[H");
    printf("***CHANGE TASK (2)***\n");
    printf("Please enter the employee's username: ");
    getInput(USER_SIZE, username, false);

    printf("Please enter the new task: ");
    getInput(TASK_SIZE, task, false);

    // Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call cambia_mansione(?,?,?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize office report statement\n", false);
	}

    // Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);

    param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = task;
	param[1].buffer_length = strlen(task);
    //out variable
    param[2].buffer_type = MYSQL_TYPE_TINY;
	param[2].buffer = &success;
	param[2].buffer_length = sizeof(success);
  
    //bind parameters
    if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for change task function\n", true);
	}

    // Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while changing the task.");
        goto out1;
	}

    memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_TINY; // OUT
	param[0].buffer = &success;
	param[0].buffer_length = sizeof(success);
    //bind for result
    if(mysql_stmt_bind_result(prepared_stmt, param)) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve output parameter", true);
	}

    // Retrieve output parameter
	if(mysql_stmt_fetch(prepared_stmt)) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not buffer results", true);
	}

    if (success)
    {
        printf("Task for employee %s correctly change to %s .",username,task);
    }
    else
    {
        printf("Error in change task");
    }

    out1:
	mysql_stmt_close(prepared_stmt);
}


void run_as_employee_admi(MYSQL *conn){
    //menu options
    char options[5] = {'1','2', '3', '4', '5'};
    char op;

    
    printf("Switching to Sector Administration role...\n");
    
    //change login user to Sector Administration user
    if(!parse_config("users/settore_amministrativo.json", &conf)) {
		fprintf(stderr, "Unable to load Sector Administration configuration\n");
		exit(EXIT_FAILURE);
	}

    if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed:%s\n",mysql_error(conn));
		exit(EXIT_FAILURE);
	}

    //prepare set for SIGINT
    sigaddset(&set,SIGINT);
    act.sa_handler = handler_ret;
    act.sa_mask = set;
    act.sa_flags = 0;
    sigaction(SIGINT,&act,NULL);

    while (true)
    {

        

       //show menu
        printf("\033[2J\033[H");
        printf("\n*** What should I do for you? ***\n\n");
        printf("1) Employee offices report\n");
		printf("2) Change employee task\n");
		printf("-------Research operations-------\n");
		printf("3) Find an employee\n");
		printf("4) Find a number\n");
        printf("5) Quit\n\n");

       op = multiChoice("Select an option", options, 5);

       switch (op)
       {
       case '1':
            office_report(conn);
            break;
        case '2':
            change_employee_task(conn);
            break;
        case '3':
            find_employee(conn);
            break;
        case '4':
            find_number(conn);
            break;
        case '5':
            return;
       
       default:
            fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
		    abort();
       }
        printf("\n\nPLEASE INSERT ENTER TO CONTINUE\n");
       getchar();
    }

}
