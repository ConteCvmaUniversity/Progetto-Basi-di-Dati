#pragma once

#include <stdbool.h>
#include <mysql.h>

struct configuration {
	char *host;
	char *db_username;
	char *db_password;
	unsigned int port;
	char *database;

	char username[128];
	char password[128];
};

#define USER_SIZE 45
#define TASK_SIZE 45


extern struct configuration conf;

//define handler
extern void handler_ret();
extern void handler_not();


//per estrapolare dati dal json
extern int parse_config(char *path, struct configuration *conf);
//per ottenere un input
extern char *getInput(unsigned int lung, char *stringa, bool hide);
//
extern bool yesOrNo(char *domanda, char yes, char no, bool predef, bool insensitive);
//mostra un messaggio all'utente per la selezione di un elemento in choices
extern char multiChoice(char *domanda, char choices[], int num);


//per fare il print su stderr di un errore sql preceduto da un messaggio del programmatore
extern void print_error (MYSQL *conn, char *message);
//per fare il print su stderr di un errore sql in stmt preceduto da un messaggio del programmatore
extern void print_stmt_error (MYSQL_STMT *stmt, char *message);
//terminato con errore sql chiude la conn
extern void finish_with_error(MYSQL *conn, char *message);
//terminato con errore sql in stmt chiude la conn e lo stmt
extern void finish_with_stmt_error(MYSQL *conn, MYSQL_STMT *stmt, char *message, bool close_stmt);
//inizializza uno statement definito in statement ritorna false se ci sono errori e fa il dovuto print in stderr
extern bool setup_prepared_stmt(MYSQL_STMT **stmt, char *statement, MYSQL *conn);
//esegue il dump del result set
extern void dump_result_set(MYSQL *conn, MYSQL_STMT *stmt, char *title);



//run dei vari client in base all'utente loggato
extern void run_as_employee(MYSQL *conn);
extern void run_as_employee_spazi(MYSQL *conn);
extern void run_as_employee_admi(MYSQL *conn);
extern void run_as_administrator(MYSQL *conn);


//common employee operation
extern void find_employee(MYSQL *conn);
extern void find_number(MYSQL *conn);


