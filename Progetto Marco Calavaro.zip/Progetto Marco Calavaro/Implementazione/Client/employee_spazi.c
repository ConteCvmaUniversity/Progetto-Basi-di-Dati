#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

#include "defines.h"

struct employee_info {
    char Nome[20];
    char Cognome[20];
    char Mansione[45];
    char Edificio[2];
    int Piano;
    int Num_ufficio;
    int Num_postazione;   
};

struct office_info {
    char Edificio[2];
    int Piano;
    int Num_ufficio;
    int Num_postazione;
    bool Occupata;   
};

static void print_dashes(){
    //specif print for office info table
    printf("+-----+----------+-------+-------------+----------------+----------+");
    putchar('\n');
}

static int choose_office(int range){
    while (true)
    {
        printf("Select a row for the office target [Numbert between 1-%d]: ",range);
        char c[10];
        getInput(10,c, false);
        int choice = atoi(c);
        if (0 < choice && choice < range + 1)
        
            return choice;

    }
}


static size_t parse_office_info(MYSQL *conn, MYSQL_STMT *stmt, struct office_info **ret)
{
    int status;
	size_t row = 0;
    MYSQL_BIND param[5];
    int Piano = 0;
    char *Edificio;
    int Num_uff = 0;
    int Num_posta=0;
    bool Occupata=false;


    if (mysql_stmt_store_result(stmt)) {
		fprintf(stderr, " mysql_stmt_execute(), 1 failed\n");
		fprintf(stderr, " %s\n", mysql_stmt_error(stmt));
		exit(0);
	}

    Edificio = malloc (2*sizeof(char));

    *ret = malloc(mysql_stmt_num_rows(stmt) * sizeof(struct office_info));
    
    memset(param, 0, sizeof(param));

    param[0].buffer_type = MYSQL_TYPE_STRING;
	param[0].buffer = Edificio;
	param[0].buffer_length = strlen(Edificio);

    param[1].buffer_type = MYSQL_TYPE_LONG;
	param[1].buffer = &Piano;
	param[1].buffer_length = sizeof(int);

    param[2].buffer_type =MYSQL_TYPE_LONG;
	param[2].buffer = &Num_uff;
	param[2].buffer_length = sizeof(int);

    param[3].buffer_type =MYSQL_TYPE_LONG;
	param[3].buffer = &Num_posta;
	param[3].buffer_length = sizeof(int);

    param[4].buffer_type = MYSQL_TYPE_TINY;
	param[4].buffer = &Occupata;
	param[4].buffer_length = sizeof(bool);

    

    if(mysql_stmt_bind_result(stmt, param)) {
		finish_with_stmt_error(conn, stmt, "Unable to bind column parameters\n", true);
	}

    while (true) {
		status = mysql_stmt_fetch(stmt);

		if (status == 1 || status == MYSQL_NO_DATA)
			break;

		
        (*ret)[row].Num_ufficio = Num_uff;
        (*ret)[row].Piano = Piano;
        strcpy((*ret)[row].Edificio, Edificio);
        (*ret)[row].Num_postazione = Num_posta;
        (*ret)[row].Occupata = Occupata;
		row++;
	}
				
	return row;


    

}

static size_t parse_employee_info(MYSQL *conn, MYSQL_STMT *stmt, struct employee_info **ret)
{
    //function for multi employee info
    int status;
	size_t row = 0;
    MYSQL_BIND param[7];
    char Nome[20];
    char Cognome[20];
    char Mansione[45];
    int Num_uff=0;
    int Num_posta=0;
    int Piano=0;
    char *Edificio;
   

    if (mysql_stmt_store_result(stmt)) {
		fprintf(stderr, " mysql_stmt_execute(), 1 failed\n");
		fprintf(stderr, " %s\n", mysql_stmt_error(stmt));
		exit(0);
	}
    Edificio = malloc (2*sizeof(char));

    *ret = malloc(mysql_stmt_num_rows(stmt) * sizeof(struct employee_info));

    memset(param, 0, sizeof(param));

    param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = Nome;
	param[0].buffer_length = 20;

    param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = Cognome;
	param[1].buffer_length = 20;

    param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = Mansione;
	param[2].buffer_length = 45;

    param[3].buffer_type = MYSQL_TYPE_STRING;
	param[3].buffer = Edificio;
	param[3].buffer_length = sizeof(Edificio);

    param[4].buffer_type = MYSQL_TYPE_LONG;
	param[4].buffer = &Piano;
	param[4].buffer_length = sizeof(int);

    param[5].buffer_type =MYSQL_TYPE_LONG;
	param[5].buffer = &Num_uff;
	param[5].buffer_length = sizeof(int);

    param[6].buffer_type =MYSQL_TYPE_LONG;
	param[6].buffer = &Num_posta;
	param[6].buffer_length = sizeof(int);    

    if(mysql_stmt_bind_result(stmt, param)) {
		finish_with_stmt_error(conn, stmt, "Unable to bind column parameters\n", true);
	}

    while (true) {
		status = mysql_stmt_fetch(stmt);

		if (status == 1 || status == MYSQL_NO_DATA)
			break;

		strcpy((*ret)[row].Nome, Nome);
        strcpy((*ret)[row].Cognome, Cognome);
        strcpy((*ret)[row].Mansione, Mansione);
        strcpy((*ret)[row].Edificio, Edificio);
        (*ret)[row].Num_ufficio = Num_uff;
        (*ret)[row].Piano = Piano;
        (*ret)[row].Num_postazione = Num_posta;
		row++;
	}
			
	return row;
}

static void print_office_result_set(char *title,struct office_info **ret,size_t row)
{
    unsigned int loop = 0;

    

        printf("%s\n", title);
        print_dashes();
        printf("| NUM | Edificio | Piano | Num Ufficio | Num Postazione | Occupata |\n");
        print_dashes();

    if (row > 0) {
        /* fetch and display result set rows */
        while (loop<row)
        { 
            putchar('|');
            
            printf(" %-*d |",3,loop+1);
            printf(" %-*s |",8,(*ret)[loop].Edificio);
            printf(" %-*d |",5,(*ret)[loop].Piano);
            printf(" %-*d |",11,(*ret)[loop].Num_ufficio);
            printf(" %-*d |",14,(*ret)[loop].Num_postazione);
            printf(" %-*s |",8,(*ret)[loop].Occupata ? "Si" : "No");

            putchar('\n');
			print_dashes();
            loop++;
        }
    }
}


static void emp_transfer_report(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;
    char header[512];
    

    printf("\033[2J\033[H");
    printf("***EMPLOYEES TO BE TRANSFERRED***\n");

    // Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call report_dipendenti_da_trasferire()", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize employee report statement\n", false);
	}

    // Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while retrieving the employee report.");
	}

    sprintf(header, "\nThose are the employees to be transferred\n");
	dump_result_set(conn, prepared_stmt, header);

    mysql_stmt_close(prepared_stmt);


}


static void trasfer_employee(MYSQL *conn){
    MYSQL_STMT *prepared_stmt;
    MYSQL_BIND param[6];
    int status;
    int num_fields;
    int office_choice;
    bool first = true;
    char username[USER_SIZE];
    char header[512];
    size_t row;
    struct employee_info *emp_info;
    struct office_info *off_info;
    

    printf("\033[2J\033[H");
    printf("***TRANSFER AN EMPLOYEE (1)***\n");

    if (yesOrNo("You want to find an employee first?",'y','n',false,true))
    {
        find_employee(conn);
        printf("\n\nPLEASE INSERT ENTER TO CONTINUE\n");
        getchar();
    }

    printf("\033[2J\033[H");
    printf("***TRANSFER AN EMPLOYEE (2)***\n");   
    printf("Please enter the employee's username: ");
    getInput(USER_SIZE, username, false);

    // Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call info_dip_e_uffici(?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize Info statement\n", false);
	}

    // Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);

    if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for offices info\n", true);
	}

    if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while retrieving the offices info.");
        goto out;
	}

    do
    {
        if(conn->server_status & SERVER_PS_OUT_PARAMS) {
			goto next;
		}

        if (first)
        {
            parse_employee_info(conn,prepared_stmt,&emp_info);
            printf("\nEmployee: %s %s \nTask: %s\n",emp_info[0].Nome, emp_info[0].Cognome,emp_info[0].Mansione);
            printf("Is currently in the office: %s-%d-%d,Seat: %d\n",emp_info[0].Edificio,emp_info[0].Piano,emp_info[0].Num_ufficio,emp_info[0].Num_postazione);
            first = false;
        }
        else
        {
            num_fields = mysql_stmt_field_count(prepared_stmt);
            
            if (num_fields>0)
            {
                row = parse_office_info(conn,prepared_stmt,&off_info);
               
                sprintf(header, "\nOffices info for task: %s\n", emp_info[0].Mansione);
                print_office_result_set(header,&off_info,row);
            }

        }

        next:
		status = mysql_stmt_next_result(prepared_stmt);
		if (status > 0)
			finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);
        
    } while (status == 0);
    //end of info, choose a target office for the transfer
    if (row > 0)
    {
        //ask office row -1 because choose_office function return number between 1 and row  
        office_choice = choose_office(row)-1;
       
        
       
        //transfer the employee in free seat
        // Prepare stored procedure call
        if(!setup_prepared_stmt(&prepared_stmt, "call trasferisci_dipendente(?,?,?,?,?,?)", conn)) {
            finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize transfer employee statement\n", false);
        }

        

        int n_po = off_info[office_choice].Num_postazione;
        int n_u = off_info[office_choice].Num_ufficio;
        int n_pi = off_info[office_choice].Piano;
        bool oc = off_info[office_choice].Occupata;

        param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
        param[0].buffer = username;
        param[0].buffer_length = strlen(username);

        param[1].buffer_type = MYSQL_TYPE_LONG;
        param[1].buffer = &(n_po);
        param[1].buffer_length = sizeof(int);

        param[2].buffer_type = MYSQL_TYPE_LONG;
        param[2].buffer = &(n_u);
        param[2].buffer_length = sizeof(int);

        param[3].buffer_type = MYSQL_TYPE_LONG;
        param[3].buffer = &(n_pi);
        param[3].buffer_length = sizeof(int);

        param[4].buffer_type = MYSQL_TYPE_STRING;
        param[4].buffer = off_info[office_choice].Edificio;
        param[4].buffer_length = strlen(off_info[office_choice].Edificio);

        param[5].buffer_type = MYSQL_TYPE_TINY;
        param[5].buffer = &(oc);
        param[5].buffer_length = sizeof(bool);

       

        if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
            finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for transfer employee\n", true);
        }

        if (mysql_stmt_execute(prepared_stmt) != 0) {
            print_stmt_error(prepared_stmt, "An error occurred while transfering employee");
        }
        
    }
    
    free(emp_info);
    free(off_info);

    out:
	mysql_stmt_close(prepared_stmt);
}


void run_as_employee_spazi(MYSQL *conn){
    char options[5] = {'1','2', '3', '4', '5'};
    char op;

    printf("Switching to Sector Spazi role...\n");

     //change login user to Sector Spazi user
    if(!parse_config("users/settore_spazi.json", &conf)) {
		fprintf(stderr, "Unable to load Sector Spazi configuration\n");
		exit(EXIT_FAILURE);
	}

    if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed:%s\n",mysql_error(conn));
		exit(EXIT_FAILURE);
	}

    while (true)
    {

       //show menu
        printf("\033[2J\033[H");
        printf("\n*** What should I do for you? ***\n\n");
        printf("1) Employees to be transferred report\n");
		printf("2) Transfer an employee\n");
		printf("-------Research operations-------\n");
		printf("3) Find an employee\n");
		printf("4) Find a number\n");
        printf("5) Quit\n\n");

       op = multiChoice("Select an option", options, 5);

       switch (op)
       {
       case '1':
            emp_transfer_report(conn);
            break;
        case '2':
            trasfer_employee(conn);
            break;
        case '3':
            find_employee(conn);
            break;
        case '4':
            find_number(conn);
            break;
        case '5':
            return;
       
       default:
            fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
		    abort();
       }

       printf("\n\nPLEASE INSERT ENTER TO CONTINUE\n");
       getchar();
    }    

}